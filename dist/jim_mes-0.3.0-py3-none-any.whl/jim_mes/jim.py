# -*- coding: utf-8 -*-
# @Author: Max ST
# @Date:   2019-04-07 11:20:56
# @Last Modified by:   maxst
# @Last Modified time: 2019-04-13 13:44:10
import time

from .convert import Converter


class Message(object):
    def __init__(self, loads=None, **kwargs):
        self.conv = Converter(type='json')
        date_format = kwargs.pop('date_format', '')
        self.delimiter = kwargs.pop('delimiter', '\r\n')
        if loads:
            self.__raw = self.conv.reads(loads)
        else:
            self.__raw = kwargs
        self.__raw['time'] = time.strftime(date_format)

    def __bytes__(self):
        return f'{self.conv.dumps(self.__raw)}{self.delimiter}'.encode()

    def __str__(self):
        response = self.text if self.text else self.__raw
        resp = self.__raw.get('response', None)
        if resp == 400:
            response = f'client error:\n{self.error}'
        elif resp == 500:
            response = f'server error:\n{self.error}'
        return '{mes}'.format(mes=response)

    def __getattr__(self, attr):
        if attr and attr not in vars(self) and not hasattr(type(self), attr):
            return self.__raw[attr] if attr in self.__raw else None
        return super().__getattr__(attr)

    @property
    def user_account_name(self):
        try:
            name = self.__raw['user']['account_name']
        except ValueError:
            return None
        return name

    @classmethod
    def success(cls, response=200, **kwargs):
        return cls(response=response, **kwargs)

    @classmethod
    def error_resp(cls, text, **kwargs):
        return cls(response=400, error=text, **kwargs)

    @classmethod
    def error_request(cls, text, **kwargs):
        return cls(action='error', msg=text, **kwargs)

    @classmethod
    def presence(cls, type_='status', user=None, **kwargs):
        return cls(action='presence', type=type_, user=user, **kwargs)
